<h1 align="center">
  <br>
  <a href="https://github.com/farisalkhat/LuigiBot"><img src="https://i.imgur.com/Asa1r52.png" alt="LuigiBot - Discord Bot"></a>
  <br>
  Luigi Discord Bot
  <br>
</h1>

<h4 align="center">Music, Moderation, Games, Stream Alerts and more!</h4>

<p align="center">
  <a href="https://discord.gg/ejAHDB">
    <img src="https://discordapp.com/api/guilds/572868639984713728/widget.png?style=shield" alt="Discord Server">
  </a>

  <a href="https://www.python.org/downloads/">
    <img src="https://img.shields.io/badge/Made%20With-Python%203.7-blue.svg?style=for-the-badge" alt="Made with Python 3.7">
  </a>
  <a href="https://github.com/Rapptz/discord.py/tree/rewrite">
      <img src="https://img.shields.io/badge/discord-py-blue.svg" alt="discord.py">
  </a>
</p>


<p align="center">
  <a href="#overview">Overview</a>
  �
 <a href="#license">License</a>
  �
</p>

# Overview


Luigi is meant to be a general purpose bot, where he contains a variety of useful and fun commands for any server to use. 
You must maintain and host your own instance of LuigiBot to utilize him. 


# License

Released under the [GNU GPL v3](https://www.gnu.org/licenses/gpl-3.0.en.html) license.

Luigi is named after the main character of the game "Super Smash Bros.", a video game starring Luigi.

Luigi's icon was made by <a href="https://mitsame.tumblr.com/ ">Mit's-A-Me!</a>


