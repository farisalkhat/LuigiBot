Luigi Discord Bot
Commands to create gaming profiles, play music, administrate servers, and more!
Made with Python 3.7

# Overview

Luigi is meant to be a general purpose bot, where he contains a variety of useful and fun commands for any server to use. 
You must maintain and host your own instance of LuigiBot to utilize him. 

https://github.com/farisalkhat/LuigiBot

# License
Released under the [GNU GPL v3](https://www.gnu.org/licenses/gpl-3.0.en.html) license.
Luigi is named after the main character of the game "Super Smash Bros.", a video game starring Luigi.
Luigi's icon was made by Mit's-A-Me.


